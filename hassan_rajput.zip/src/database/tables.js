export const Table = {
  USERS: "users",
  ROLES: "roles",
  USER_ROLES: "user_roles",
  COMPONENTS: "components",
};
