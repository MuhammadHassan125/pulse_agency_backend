import { Router } from "express";
import {
  addComponent,
  addRole,
  deleteComponent,
  deleteRole,
  readComponentById,
  readComponents,
  readRoleById,
  readRoles,
  updateComponent,
  updateRole,
} from "./controllers.js";

import {
  AddComponentValidation,
  AddRoleValidation,
  updateComponentValidation,
  updateRoleValidation,
} from "./validations.js";

import { errorHandler } from "../middlewares/errorHandler.js";

import { authenticate } from "../middlewares/auth.js";

export const Admin = Router();

Admin.post(
  "/role/add",
  (req, res, next) => {
    authenticate(req, res, next, "super_admin");
  },
  AddRoleValidation,
  errorHandler(addRole)
)

  .get(
    "/role/read/:id",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    errorHandler(readRoleById)
  )

  .get(
    "/role/read",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    errorHandler(readRoles)
  )

  .put(
    "/role/update",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    updateRoleValidation,
    errorHandler(updateRole)
  )

  .delete(
    "/role/delete/:id",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    errorHandler(deleteRole)
  )

  .post(
    "/component/add",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    AddComponentValidation,
    errorHandler(addComponent)
  )

  .post(
    "/component/read/:id",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    errorHandler(readComponentById)
  )

  .post(
    "/component/read",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    errorHandler(readComponents)
  )

  .post(
    "/component/update",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    updateComponentValidation,
    errorHandler(updateComponent)
  )

  .post(
    "/component/delete",
    (req, res, next) => {
      authenticate(req, res, next, "super_admin");
    },
    errorHandler(deleteComponent)
  );
