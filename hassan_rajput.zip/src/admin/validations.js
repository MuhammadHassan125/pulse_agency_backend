import Joi from "joi";
import { handleError } from "../services/utils/responseUtils.js";
import { Validator } from "../middlewares/validator.js";

export const AddRoleValidation = (req, res, next) => {
  try {
    const schema = Joi.object({
      name: Joi.string().required(),
    });

    return Validator(req.body, res, next, schema);
  } catch (error) {
    return handleError(res, error);
  }
};

export const updateRoleValidation = (req, res, next) => {
  try {
    const schema = Joi.object({
      id: Joi.number().required(),
      name: Joi.string().required(),
    });

    return Validator(req.body, res, next, schema);
  } catch (error) {
    return handleError(res, error);
  }
};

export const AddComponentValidation = (req, res, next) => {
  try {
    const schema = Joi.object({
      name: Joi.string().required(),
      page: Joi.string().required(),
      header: Joi.string().required(),
      content: Joi.string().required(),
    });

    return Validator(req.body, res, next, schema);
  } catch (error) {
    return handleError(res, error);
  }
};
export const updateComponentValidation = (req, res, next) => {
  try {
    const schema = Joi.object({
      id: Joi.string().required(),
      name: Joi.string().required(),
      header: Joi.string().required(),
      content: Joi.string().required(),
    });

    return Validator(req.body, res, next, schema);
  } catch (error) {
    return handleError(res, error);
  }
};
