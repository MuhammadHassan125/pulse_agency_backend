export const ROLES = [
  { id: 1, name: "user" },
  { id: 2, name: "super_admin" },
  { id: 3, name: "admin" },
  { id: 4, name: "sub admin" },
];
